f = @(x)exp(x) - x^4; 


a =-1;
b= 1;
f_a = f(a);
f_b = f(b);
m = (a +b)/2;
TOL = abs(b-a);


%we now do the bisection algorithm
count =1;
while (TOL >10^-6)
    if f_a * f_b <0
    %fprintf('there exists a root in the interval')
    
    m = (a +b)/2;
    %disp(m);
    
    if f(m) <0
        a=m;

    else 
        b=m;
    end
    count = count +1;  
    
    end
    
    TOL = abs(b-a);
end       
   
    fprintf('the root of f(x) near -1  is %.16f\t',  m)
a = 1;
b=2;
    
f_a = f(a);
f_b = f(b);
m = (a +b)/2;
TOL = abs(b-a);


%we now do the bisection algorithm
count =1;
while (TOL >10^-6)
    if f_a * f_b <0
    %fprintf('there exists a root in the interval')
    
    m = (a +b)/2;
    %disp(m);
    
    if f(m) <0
        a=m;

    else 
        b=m;
    end
    count = count +1;  
    
    end
    
    TOL = abs(b-a);
end       
   
    fprintf('the root of f(x) near 1 is %.16f\t',  m)
a= 8;
b=9;
f_a = f(a);
f_b = f(b);
m = (a +b)/2;
TOL = abs(b-a);


%we now do the bisection algorithm
count =1;
while (TOL >10^-6)
    if f_a * f_b <0
    %fprintf('there exists a root in the interval')
    
    m = (a +b)/2;
    %disp(m);
    
    if f(m) <0
        a=m;

    else 
        b=m;
    end
    count = count +1;  
    
    end
    
    TOL = abs(b-a);
end       
   
    fprintf('the root of f(x) near 9 is  %.16f\t',  m )
    
