import numpy as np
import random
import matplotlib as mp
import matplotlib.pyplot as plt
import csv
import math
from scipy.optimize import curve_fit

with open('data_1.csv', 'r') as file1:
	reader = csv.reader(file1,delimiter=',')
	for coloumns1 in reader:
        	print(coloumns1[1])


with open('data_2.csv', 'r') as file2:
	reader = csv.reader(file2,delimiter=',')
	for coloumns2 in reader:
        	print(coloumns2[1])

with open('data_3.csv', 'r') as file3:
	reader = csv.reader(file3,delimiter=',')
	for coloumns3 in reader:
        	print(coloumns3[1])

def fitfunction(t,A,tau):
	return A*math.exp(-float(t)/tau)

x1=coloumns1[0];
y1 = coloumns1[1];
x2=coloumns2[0];
y2 = coloumns2[1];
x3=coloumns3[0];
y3 = coloumns3[1];


#fit to Aexp(-t/tau)
init_vals=[100,2]
fits,cov=curve_fit(fitfunction,x1,y1,p0=init_vals)
print(fits)
fits,cov=curve_fit(fitfunction,x2,y2,p0=init_vals)
print(fits)
fits,cov=curve_fit(fitfunction,x3,y3,p0=init_vals)
print(fits)


fig = plt.figure()
ax1 = fig.add_subplot(111)

ax1.scatter(x1, y1, s=10, c='b', marker="s", label='data1')
ax1.scatter(x2,y2, s=10, c='r', marker="o", label='data2')
ax1.scatter(x3,y3, s=10, c='g', marker="o", label='data3')
plt.legend(loc='upper left');

#plt.scatter(x1,y1)
plt.plot(x1,fitfunction(x1,*fits))
plt.plot(x2,fitfunction(x2,*fits))
plt.plot(x3,fitfunction(x3,*fits))
plt.show()
