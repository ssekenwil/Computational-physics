M = zeros(50,50);% declaring a 50by 50 matrix 
%lambda= zeros(50,1); %initialising array for eigen values
for i=1:50
    for j=1:50
        if abs(i-j)<3
            M(i,j)=1;
        else 
            M(i,j)=0;
        end
    end
end


[V,D]= eig(M);
lambda_max = max(diag(D));
disp(lambda_max);% the maximum eigen value of the matrix M
for j=1:50
    if D(j,j) == lambda_max
        disp(V(:,j)); %this is the veigen vector that corresponds to the largest eigenvalue 
    end
end