M = zeros(50,50);% declaring a 50by 50 matrix 
%lambda= zeros(50,1); %initialising array for eigen values
for i=1:50
    for j=1:50
        if abs(i-j)<3
            M(i,j)=1;
        else 
            M(i,j)=0;
        end
    end
end


b0 = ones(50,1); % initialising vector bo

myarray = zeros(50,50);%initialise array whose rows are b vectors
myarray(1,:)=b0;  
k=2;

myarray(k,:)= (myarray(k-1,:)*M)/norm(myarray(k-1,:));


toll = abs(myarray(k,1) -myarray(k-1,1));

while (toll< (10^-6)*norm(myarray(k,:)))
    myarray(k,:)= (myarray(k-1,:)*M)/norm(myarray(k-1,:));
    k = k+1;
end
disp(k);
disp(myarray(k,:))