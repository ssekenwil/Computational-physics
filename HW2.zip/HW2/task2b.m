%initialization
N = 100000;
x = zeros(1,N);
v = zeros(1,N);
t = zeros(1,N);
g2 =zeros(1,6);
g1 =zeros(1,6);
%initial values
time_step = [0.5 0.1 0.05 0.01 0.005 0.001];
x(1) = 0;
v(1) = 1;
t(1) = 0;


%definig the functions
 f1 =@(t,x,v) v;

 f2 =@(t,x,v) -x;


k=1;
while  k<7
    tau = time_step(k);
    i=1;
    while i<100000
        k1x = f1(t(i),x(i),v(i));
        k1v = f2(t(i),x(i),v(i));
        k2x = f1(t(i) + 0.5*tau,x(i) + 0.5*tau*k1x,v(i) + 0.5*tau*k1v);
        k2v = f2(t(i) + 0.5*tau,x(i) + 0.5*tau*k1x,v(i) + 0.5*tau*k1v);
        k3x = f1(t(i) + 0.5*tau,x(i) + 0.5*tau*k2x,v(i) + 0.5*tau*k2v);
        k3v = f2 (t(i) + 0.5*tau,x(i) + 0.5*tau*k2x,v(i) + 0.5*tau*k2v);
        k4x = f1(t(i) +tau, x(i) + tau*k3x, v(i) + tau*k3v);
        k4v = f2(t(i) +tau, x(i) + tau*k3x, v(i) + tau*k3v);
        x(i+1) = x(i) + (tau/6)*(k1x+ 2*k2x + 2*k3x + k4x);
        v(i+1) = v(i) + (tau/6)*(k1v+ 2*k2v + 2*k3v + k4v);
        t(i+1) = t(i) + tau;
        i =i+1;
    
    end
    xrk4_5 = interp1(t,x,5);
    g2(k) = abs(sin(5)- xrk4_5);
    %disp(xrk4_5)
    k=k+1;
end




%initialising again
N = 100000;
xv = zeros(1,N);
vv = zeros(1,N);
tt = zeros(1,N);



xv(1) = 0;
vv(1) = 1;
tt(1) = 0;
l=1;

while  l<7
    tau = time_step(l);
    m=1;
    while m<100000
        xv(m+1) =  (1 - 0.5*(tau^2))*xv(m) + tau*vv(m);
          
        vv(m+1) = vv(m) - 0.5*(xv(m+1)+ xv(m))*tau;
       
        tt(m+1) = tt(m) + tau;
        m = m+1;
        %disp(x(m))
    end  
   
    xverlet_5 = interp1(t,x,5);
    g1(l) = abs(sin(5)- xverlet_5);
    disp(xverlet_5)
    l=l+1;
    
end

loglog(time_step,g1,'r', time_step, g2, 'g');
legend('verlet', ' rk4')


