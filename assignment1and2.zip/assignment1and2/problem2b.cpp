#include <iostream>
#include <stdio.h>
#include <cmath>


using namespace std;

int main()
{
double x ,y,n;
cin>>n;
for (x=1.0;x<n;x++)
{
double y = pow(2.0,x);
cout << y <<'\n';
}
return 0;
}

//i entered values of n and realised that for my computer, 2^1034 is the largest power of 2.0 that can be represented of double type. this is because, beyond 2^1034, the computer outputs inf which is not a number.
