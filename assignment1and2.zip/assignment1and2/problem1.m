
f_prime_exact = 9*exp(-t0)/ ((1 + 9*exp(-t0))^2);
x_old = 1/( 1 + 9*exp(-t0));

for n = 0:20
    t0 =2;
    
    del_t = 10^-n;
    x_new = 1/( 1 + 9*exp(-1*(t0 + del_t)));
    f_del_t = abs(f_prime_exact- ((x_new-x_old)/del_t));
    vpa(x_new,9);
    fprintf('%16.f\n', x_new)
end

