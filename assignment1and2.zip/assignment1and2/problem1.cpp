#include <iostream>
#include <stdio.h>
#include <cmath>
#include <iomanip>   
#include <fstream>

using namespace std;

int main()
{
	ofstream myfile;
	myfile.open ("xcpp.dat");
	double f_prime_exact,t,t0=2;
	int n;
	double del_t;
	double x[20]; //an array to store x(t) values
	f_prime_exact = 9*exp(-1*t0)/(pow(1+9*exp(-1*t0),2));
	double x_n = 1/(1 + 9*exp(-1*t0));



		for(n=0; n<21;n++)
		{
		
			del_t = pow(10.0,(-1.0*n));
		        x[n] = 1/(1 + 9*exp(-1*(t0 + del_t)));
			
			double f_del_t = abs(f_prime_exact - (x[n]-x_n)/del_t);
			std::cout <<del_t << "  "<< std::setprecision(9) << f_del_t << '\n';
			myfile<<del_t << "  "  << f_del_t <<"\n";
			
			
			
		}
myfile.close();

return 0;
	
}


