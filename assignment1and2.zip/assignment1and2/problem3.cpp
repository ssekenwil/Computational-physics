#include <iostream>
#include <stdio.h>
#include <cmath>
#include <fstream>
#include <bits/stdc++.h>
#define vec_size 3

using namespace std;

   
//function to do GSO

void GSO(double vec_a[], double vec_b[],double v2[])
	{
//calculate dot product of vectors a and b
	 double dot_pdt = vec_a[0]*vec_b[0] + vec_a[1]*vec_b[1] +vec_a[2]* vec_b[2];
// calculate the square modulus of vector a
	 double sq_modulus_a = (vec_a[0]*vec_a[0]) + (vec_a[1]*vec_a[1]) +(vec_a[2]* vec_a[2]);
// calculate the modulus of vector b
	double modulus_b = sqrt((vec_b[0]*vec_b[0]) + (vec_b[1]*vec_b[1]) +(vec_b[2]* vec_b[2]));
//elements of the other GSO vector
	 v2[0] = vec_b[0] - ((dot_pdt*vec_a[0])/(1.0*sq_modulus_a));
	 v2[1] = vec_b[1] - ((dot_pdt*vec_a[1])/(1.0*sq_modulus_a));
	 v2[2] = vec_b[2] - ((dot_pdt*vec_a[2])/(1.0*sq_modulus_a));
// calculate the modulus of vector v2

	//double modulus_v2= sqrt((v2[0]*v2[0]) + (v2[1]*v2[1]) +(v2[2]* v2[2]));

// calculate value of constant vector c that ensures |v2| =|b|
	//c = modulus_b/modulus_v2;
	}


int main()
{
	double v2[vec_size];
	double vec_a[] = {1,2,3};
	double vec_b[] = {2,1,3};
	double c;
	//cout << vec_dot_product( vec_a, vec_b) << endl;
	
	cout<<"from GSO, v2=:";

	GSO( vec_a, vec_b,v2);
	for (int i=0; i< vec_size; i++)
	//cout<< v2[i]<< " ";
	//cout<< v2[i]<< " ";
	// to ensure |v2| =|vec_b|
	cout<< v2[i]*(sqrt((vec_b[0]*vec_b[0]) + (vec_b[1]*vec_b[1]) +(vec_b[2]* vec_b[2]))/sqrt((v2[0]*v2[0]) + (v2[1]*v2[1]) +(v2[2]* v2[2])))<<" ";

	cout<<"\n";
	cout<<"from GSO, v1=:";
	for (int i=0; i<vec_size; i++)
	cout<< vec_a[i]<< " ";

	return 0;
}

