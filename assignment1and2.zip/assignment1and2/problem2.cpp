#include <iostream>
#include <stdio.h>
#include <cmath>
#include <fstream>

using namespace std;

int main()
{
int x =1,y,n;
cin>>n;
for (x=1;x<n;x++)
{
int y = pow(2,x);
cout << y <<'\n';
}
return 0;
}

//i entered values of n and realised that for my computer, 2^30 is the largest power of 2 that can be represented of int type. this is because, beyond2 2^30, the computer outputs negative numbers yet i know that the power of a positive number should be positive.
