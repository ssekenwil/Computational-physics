#import numpy as np
import math
import array as arr



for x in range (1,66):

	
	y= x//1
	
	print(x,pow(2,x))
	
	
	
# for python, i can print out any power of 2 as an integer. To me this is suprising because when made some research about this on internet, i saw that 2^63 is the largest possible integer by python.
# the code above just takes more time about 3 minutes but it still displays an integer.
