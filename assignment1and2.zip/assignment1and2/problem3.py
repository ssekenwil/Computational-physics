import math
import array
import numpy as np
#defining the GSO function

def GSO(vec_a, vec_b):
	
	#calculate dot product of vectors a and b
	dot_pdt = vec_a[0]*vec_b[0] + vec_a[1]*vec_b[1] +vec_a[2]* vec_b[2];
	sq_modulus_a = (vec_a[0]*vec_a[0]) + (vec_a[1]*vec_a[1]) +(vec_a[2]* vec_a[2]);
	modulus_b = math.sqrt((vec_b[0]*vec_b[0]) + (vec_b[1]*vec_b[1]) +(vec_b[2]* vec_b[2]));
	v2_i = vec_b[i] - ((dot_pdt*vec_a[i])/(1.0*sq_modulus_a));
	return v2_i;
	




#calling the function
vec_a =array.array ('i',[1,2,3]);# vector a
vec_b = array.array('i',[2,1,3]);# vector b

v2_i = GSO(vec_a, vec_b);

print("v2 = ")
for i in range(3):
	print( v2_i)

