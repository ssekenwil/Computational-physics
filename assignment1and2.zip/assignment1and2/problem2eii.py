#import numpy as np
import math
import array as arr



for x in range (1,66):

	
	y= x/1.0
	
	print(x,pow(2.0,x))
	
	
# from python code above, 2^53  is the largest power of 2.0 that can be printed be printed without using scientific notation.
