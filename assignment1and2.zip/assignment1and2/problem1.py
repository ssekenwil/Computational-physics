#import numpy as np
import math
import array as arr


#x = arr.array('d', [])
#x =numpy.empty(shape=(20,2),dtype='d') 
t0 =2
f_prime_exact = 9*math.exp(-1*t0)/(pow(1+9*math.exp(-1*t0),2))
x_old = 1/(1 + 9*math.exp(-1*t0))
f = open("xpy.dat", "a")
for n in range(21):

	del_t = pow(10.0,(-1.0*n))
	
	x_new = 1/(1 + 9*math.exp(-1*(t0 + del_t)))
	f_del_t = abs(f_prime_exact - (x_new-x_old)/del_t)
	print( del_t, f_del_t)
	#f.write( del_t, f_del_t )
	f.write(str( del_t) +'\t'+'\t'+str(f_del_t)+'\n')
#f.close
