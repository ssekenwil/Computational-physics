%% pendul - Program to compute the motion of a simple planet
% using the Euler or Verlet method
clear all;  help threebody      % Clear the memory and print header

%% * Select the numerical method to use: Euler or Verlet
NumericalMethod = menu('Choose a numerical method:', ...
                       'Euler','Verlet');
					   
%% * Set initial position and velocity of planet 1
%r01 = input('Enter initial position of first star : ');
r01 = [0,0];
r1 = r01;   
v1 = [0,0];               % Set the initial velocity of first star
%accel1 = zeros(1,2);
%% * Set initial position,velocity of planet 2
%r02 = input('Enter initial position of second star : ');
r02 =[0,1];
r2 = r02;   
v2 = [1,0];               % Set the initial velocity of second star
%accel2 = zeros(1,2);

%% * Set initial position and velocity of planet 3
%r03 = input('Enter initial position of third star : ');
r03 = [0,-1];
r3 = r03;   
v3 = [-1,0];               % Set the initial velocity of third star
%accel3 = zeros(1,2);

%% * initial kinetic and potential energy of system
K_old = 0.5*((norm(v1))^2 +(norm(v2)^2) + (norm(v3)^2));

U_old = - ((1/norm(r1-r2))+ (1/norm(r1-r3))+ (1/norm(r2-r3)));


%% * Set the physical constants and other variables
G_times_M = 1;            % The constant g/L
time = 0;                % Initial time
irev = 0;                % Used to count number of reversals
period = [];             % Used to record period estimates
%tau = input('Enter time step: ');
tau = 0.01
%% * Take one backward step to start Verlet

%% * for first star
accel1 = -((r1 -r2)/(norm(r1-r2))^3)  - ((r1 -r3)/(norm(r1-r3))^3) ;    % Gravitational acceleration
r1_old = r1 - v1*tau + 0.5*tau^2*accel1; 
 

%% for second star

accel2 = -((r2 -r1)/(norm(r2-r1))^3)  - ((r2 -r3)/(norm(r2-r3))^3) ;    % Gravitational acceleration
r2_old = r2 - v2*tau + 0.5*tau^2*accel2;    

%% for third star
accel3 = -((r3 -r1)/(norm(r3-r1))^3)  - ((r3 -r2)/(norm(r3-r2))^3) ;    % Gravitational acceleration
r3_old = r3 - v3*tau + 0.5*tau^2*accel3;    

%% * Loop over desired number of steps with given time step
%    and numerical method
%nstep = input('Enter number of time steps: ');
nstep = 5000;
for istep=1:nstep  

  %* Record position and time for plotting
  t_plot(istep) = time;
  r1x_plot(istep) = r1(1,1);
  r2x_plot(istep) = r2(1,1);
  r3x_plot(istep) = r3(1,1);
  
  r1y_plot(istep) = r1(1,2);
  r2y_plot(istep) = r2(1,2);
  r3y_plot(istep) = r3(1,2);
  K(istep) = 0.5*((norm(v1))^2 +(norm(v2)^2) + (norm(v3)^2));
  U(istep) = - ((1/norm(r1-r2))+ (1/norm(r1-r3)) + (1/norm(r2-r3)));
  %disp(r3y_plot(istep));
  time = time + tau;
  
  %* Compute new position and velocity using 
  %    Euler or Verlet method
  accel1 = -((r1 -r2)/(norm(r1-r2))^3)  - ((r1 -r3)/(norm(r1-r3))^3) ; % Gravitational acceleration
  accel2 = -((r2 -r1)/(norm(r2-r1))^3)  - ((r2 -r3)/(norm(r2-r3))^3) ;
  accel3 = -((r3 -r1)/(norm(r3-r1))^3)  - ((r3 -r2)/(norm(r2-r3))^3) ;
  
  
  %% * for the first star
  if( NumericalMethod == 1 )
    r1_old = r1;               % Save previous position
    r1 = r1 + tau*v1;       % Euler method
    v1 = v1 + tau*accel1; 
    
    % for second star
    r2_old = r2;               % Save previous position
    r2 = r2 + tau*v2;       % Euler method
    v2 = v2 + tau*accel2; 
    
    %for third star
    r3_old = r3;               % Save previous position
    r3 = r3 + tau*v3;       % Euler method
    v3 = v3 + tau*accel3;
    
  else  
    % for first star
    r1_new = 2*r1 - r1_old + tau^2*accel1;
    % calculate velocity and kinetic energy for star 1
    v1_new = (r1_new - r1_old)/(2*tau);
    
    
    % for second star
    r2_new = 2*r2 - r2_old + tau^2*accel2;
    % calculate velocity and kinetic energy for star 2
    v2_new = (r2_new - r2_old)/(2*tau);
    
    
    % for third star
    
    r3_new = 2*r3 - r3_old + tau^2*accel3;
    
    % calculate velocity for star 3
    v3_new = (r3_new - r3_old)/(2*tau);
   
    
    % calculating the potential, kinetic  energy of the system
    U = - (1/norm(r1_new-r2_new) + norm(r1_new-r3_new) + norm(r2_new-r3_new));
    
    K = 0.5*((norm(v1_new))^2 + (norm(v1_new))^2+ (norm(v1_new))^2);
    %K= K_old;
    %U = U_old;
    r1_old = r1;			   % Verlet method
    r1 = r1_new; 
    r2_old = r2;			   % Verlet method
    r2 = r2_new; 
    r3_old = r3;			   % Verlet method
    r3 = r3_new; 
  end
  
  end
   
  %% * Test if the planet has passed through r = 0;
  %    if yes, use time to estimate period
  %if( r1*r1_old < 0 )  % Test position for sign change
   % fprintf('Turning point at time t= %f \n',time);
   % if( irev == 0 )          % If this is the first change,
    %  time_old = time;       % just record the time
    %else
     % period(irev) = 2*(time - time_old);
     % time_old = time;
    %end
    %irev = irev + 1;       % Increment the number of reversals
  %end


%% * Estimate period of oscillation, including error bar
%AvePeriod = mean(period);
%ErrorBar = std(period)/sqrt(irev);
%fprintf('Average period = %g +/- %g\n', AvePeriod,ErrorBar);

%% * Graph the oscillations as r versus time
figure(1); clf;    % Clear figure window #1 and bring it forward
%plot(t_plot,r1_plot,'+');
plot(r1x_plot,r1y_plot,'+',r2x_plot,r2y_plot,'.',r3x_plot,r3y_plot,'*' );
xlabel('x');  ylabel('y');
legend('star1','star2','star3');
grid;

pause(1)
figure(2)
clf;
plot(t_plot,K,'+',t_plot,U,'*');