%wall=60;  %signal from the wall, which we dont' care about
%signal=200;  %true signal frequency
dt=1/128;  %sampling rate (ms rate)

T=1;  %sample time
tvals=(1:(T/dt))*dt;

%noiseScale=1;
%x=1*sin(2*pi*tvals*signal)+.5*sin(2*pi*tvals*wall)+noiseScale*randn(size(tvals));
x = csvread('data.csv');

trans=fft(x);
mag=abs(trans);

figure 

plot(mag)
xlabel('frequency index (f in units of 1/dt)')
ylabel('X(f)')

figure()

plot(tvals,x)
xlabel('t (units of dt)')
ylabel('x(t)')

y = zeros(1,128);
for i=1:127
    y(1,i) = (x(1,i)+x(1,i+1))/2.0;
    y(1,128)= y(1,1);
end 
disp(y);
trans=fft(y);
mag=abs(trans);

figure 

plot(mag)
xlabel('frequency index (f in units of 1/dt)')
ylabel('Y(f)')


figure()

plot(tvals,y)
xlabel('t (units of dt)')
ylabel('y(t)')