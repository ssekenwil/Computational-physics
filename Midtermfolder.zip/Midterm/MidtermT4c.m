
%nrow =[10 20 50 100 200 500 1000 2000];
T = zeros(1,8);


n =10;
   
    
A = zeros(n,n);

        for i=1:n
            for j=1:n
        
                A(i,j)= (1+ kronDel(i,j))/(n+1);
            end
        end

    %initialize sum to compute logarithm of matrix A
        Identity_M = eye(n,n);

        tic
        %syms k x;
        %log_A = -1*symsum(((Identity_M -A)^k)/k,k,1,Inf);
        sr=0;
        lastterm = 100;
        for k=1:lastterm
        sr=sr+ ((Identity_M - A)^k)/k;
        end
    
        T= toc;
        %T = toc;
        disp(T);
    %disp(sr)
%end 
%disp(T)

fileID = fopen('Midtermdata.txt','w');
%fprintf(fileID,'%6s %12s\n','x','exp(x)');
fprintf(fileID,'%6.2f %12.8f\n',sr);
fclose(fileID);
%loglog(n,T);
    function d = kronDel(j,r)

    if j == r
    d = 1;
    else
        d = 0;
    end

    end


